==JEDI KNIGHT Jedi Academy Map==================================

Title                   : Rift Duell V 1.5
File Name               : rift_duell_v1_5.pk3
Author                  : Keiran (Jan R.)
Date of Release         : 09-2003
Email Address           : keiran1@gmx.de


Development machine     : AMD-XP 1.533Ghz, 512 RAM, GF3 Ti200
================================================================

* Play Information *

Level name              : Rift Duell Version 1.5
JK version required     : Jedi Academy

New versions features   : Bot Support
                          Native Flares
                          Better Lightning

* Construction *

Base                    : Jedi Academy
Editor(s) used          : GTK Radiant
Build Time		: 7h
Known Bugs              : %


================================================================

Installation Notes:

Just extract the rift_duell_v1_5.pk3 to \GameData\base

================================================================


* I admit that * 
(as required by the LEC Licence Agreement about Addon Levels)

1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Level does not include any LEC sound effects or music files or 
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.

* Copyright / Permissions *

Authors MAY use this level as a base to build additional levels(just mention the author ;) ).  
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.


You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 

