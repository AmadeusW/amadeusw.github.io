15/january/04
================================================================
Map Name                : Mobil Ave station (mobilave.pk3)
Author                  : MeusH (Amadeus Wieczorek)
Email Address           : amadeuszw@wp.pl jedi@delart.pl
Web page		: jedi.delart.pl
Map description         : Duel and Power Duel map for Jedi Academy.


================================================================
* Map Information *

New Sounds              : Yes. New music.
New Textures		: Yes. Most textures used in map are custom.
Botroute		: Yes.


This is a simple Duel and Powerduel map. It's set in a strange subway station from Matrix Revolutions.
There are two main duel areas. One is in the passage, second on the platform.

You can teleport from one end of map to second (like Neo, when he tried to get into tunnel).
There is a part of wall, which is being destroyed when somebody is near (trainman pushed Neo there).

I was making this map watching Matrix Revolutions.

Brush count	: 124
Enity count	: 81
Spawn points	: 5
Compile time	: 2 minutes, 57 seconds

Software used: Radiant, Photoshop 7, Notepad, WinZip




================================================================
* How To Use This Map *

Unzip mobile_ave.zip into your GameData/base directory. You can select this map thru multiplayer menu.




================================================================

* Copyright / Permissions *

THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY LLC.  ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

All original content copyright 2003. All rights are reserved.

You may only distribute this map if it is free, unaltered, and this readme file (duel_falls_readme.txt) is included. You can not use this map as a basis for your own works.

* Other Legal *

Professional Driver on closed course.
This map contains textures of rocks and dirt. Do not throws rocks at people. Do not eat dirt. Doing so may cause serious bodily harm or even death.
This map contains a representation of a bridge. Do not jump off bridges, even if your friends do it first. Doing so may cause serious bodily harm or even death.
Do not build a real lightsaber and try to duel your friends with it. Doing so may cause serious bodily harm or even death.
Do not try to imitate anything seen or done while playing this map. You are responsible for your own stupidity.