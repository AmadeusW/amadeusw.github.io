*********************************************
JEDI KNIGHT III: Jedi Acadamy Bullet Time mod
*********************************************

Title				: Bullet Time mod
Author				: MeusH
E-Mail				: amadeuszw@wp.pl or jedi@delart.pl
Website				: http://www.jedi.delart.pl/projects.htm

File Name			: speed.cfg
File Size			: 410 Bytes
Date Released			: 29th May 2004

Game Type			: Single Player only

Installation:			: Put the speed.cfg into your /gamedata/base/ directory.
				  Open console and type
				  exec speed
				  Information about installation should appear.
				  You can use K to slow down the time and L to back to normal time.
				  You can also change binds by editing speed.cfg file

Uninstall			: Unbind binded keys (LOL)



THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.