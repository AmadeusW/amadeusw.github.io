*************************
JEDI ACADEMY MODIFICATION
*************************

Title			: Human Male 2
Version			: 1.2
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: amadeuszw@wp.pl  jedi@delart.pl
Website			: www.jedi.delart.pl/projects.htm

File Name		: humanmale2.pk3
File Size		: 710 KB
Date Released		: 8th may 2004
Date Released v. 1.1	: 29th april 2004
Date Released v. 1.2	: 20th may 2004

*************************

Description		: This mod adds new species. It is Human Male, second version. Based on Jedi model.
			  I just wanted to play with some cool guy, so I've started to make this mod.

Head count: 6
Torso count: 11
Legs count: 6

New textures: Yes
New sounds: No, but using non-Jaden sounds. Using sounds of Jedi Trainer
MP support: Yes

There can be next version of this mod, including more custom skins and many other stuff.


*************************
                          
Know bugs: No
                          
Install 		: Unzip the humanmale2.pk3 file into your GAMEDATA\BASE folder
Uninstall               : Delete humanmale2.pk3 from the GAMEDATA\BASE folder


*************************

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.