*************************
JEDI ACADEMY MODIFICATION
*************************

Title			: Laser hilts
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: amadeuszw@wp.pl  jedi@delart.pl
Website			: www.jedi.delart.pl/projects.htm

File Name		: laserhilts.pk3
File Size		: 1,97 KB
Date Released		: 4th april 2004

*************************

Description		: This mod adds new saber hilts avaible to choose.
			  There are two hilts avaible: Laser hilt and Dual laser hilt.

New models:	Yes
New sabers:	Yes: Single and two-handed
New textures:	What? 0 skins!

*************************
                          
Comments		: It is my first model avaible to download.
			  I was very scared of UVW mapping, so I decided to make a hilt without any skin.
			  This model constain 0 polygons. 0 shapes. 0 skins. Just reference tags.
			  I hope you like the idea.

if You ask "Hey, it's impossible to carry a lightsaber blade"!
I will respond "It is a new forcepower: Force Saber"

Note, that single saber has two blades, and two-handed saber has four blades, you can make twice damage!

Build time              : 4 hours
                          
Install 		: Unzip the laserhilts.pk3 file into your BASE folder
Uninstall               : Delete laserhilts.pk3 from the BASE folder


*************************

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.