**************************************
JEDI KNIGHT: JEDI ACADEMY MODIFICATION
**************************************

Title			: +Models (v. 1.0)
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: Amadeuszw@wp.pl
Website			: www.jedi.delart.pl

File Name		: +Models.pk3
File Size		: 592 kb
Date Released		: 22 November 2003



This mod lets You play some characters seen in SP:

*Lannik Racto from mission on Coruscant
*Elder from mission on Nar Kreeta
*Jedi Master from academy on Yavin 4



-New Textures: NO
-New Sounds: NO
-Team colors: YES
-Bots: YES


Note:
If you want to play with Lannik Racto bot, choose "Lannik Racto civil",
because there is another guy called "Lannik Racto" (it's normal human solider)


** How to install **


Place the +Models.pk3 in GameData\base in your game directory.


**                **




Copyright / Permissions
THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
ACTIVISION, RAVEN, OR LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

