22 feb 04
================================================================
Map Name                : Yalara landing pad
Author                  : MeusH (Amadeus Wieczorek)
Email Address           : amadeuszw@wp.pl jedi@delart.pl
Web page		: jedi.delart.pl
Map description         : Small FFA, Duel and Power Duel map for Jedi Academy.
Filesize		: 478 KB

================================================================
* Map Information *

Botroute - Yes
New textures - No
New music - No

This is a landing pad over big dam on planet Yalara
where is located SP level 't3_hevil'
This map has bot route, so you can duel with bots.

I've also included 3 'secret' places:

1 - Hit use button when you are in front of doors - large shield booster
2 - Jump above the doors, collect a Big Bacta tank
3 - Use force speed, and jump at buildings that sorrounds map (good for admins, or clan leaders)


Brush count	: 258
Enity count	: 118
Spawn points	: 5
Compile time	: 2 minutes, 57 seconds

Software used: GTK Radiant 1.4.0, Notepad, WinZip




================================================================
* How To Use This Map *

Unzip yalarapad.zip to your GameData/base directory.
And enjoy it!

================================================================

* Copyright / Permissions *

THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY LLC.  ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.
All original content copyright 2004. All rights are reserved.

You may only distribute this map if it is free, unaltered, and this readme file (yalara_readme.txt) is included. You can not use this map as a basis for your own works.