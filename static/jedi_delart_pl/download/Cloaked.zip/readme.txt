*************************
JEDI ACADEMY MODIFICATION
*************************

Title			: Cloaked Imperial Saboteur
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: amadeuszw@wp.pl  jedi@delart.pl
Website			: jedi.delart.pl

File Name		: cloaked.pk3
File Size		: 940 KB
Date Released		: 15th january 2004

*************************
Description:
		

What is it?
 This is a mod that lets you cloak when playing Imperial Saboteur.

Why he?
 Because in JA SP he is the one guy with cloaking device!

How can I use this mod?
 In JA MP bring down console ( Shift + ~ )
 and type:   exec cloak
 Start playing!
 Hit Q to decloak nad W to cloak

Are in this mod some bugs?
 When you have jetpack, it is visible...

Can I play CTF with this mod?
 Of course!
 
New sounds: No
New textures: No
New players: Yes
Bot support: Yes
Team support: Yes


Credits: Raven Software for model + skin + sounds + great game !
         Me for shader + bot

Additional thanx for somebody who made
"stealth trooper" player for JK2.
I've used some his parts of .shader file.
I know only his mail addres:
slurpy_commando@yahoo.com


*************************
                                                 
Install 		: Unzip cloaked.pk3 and cloaked.cfg files into your BASE folder
Uninstall               : Delete cloaked.pk3 and cloaked.cfg from the BASE folder

How to use?		  Read "description"

*************************

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

