*************************
JEDI ACADEMY MODIFICATION
*************************

Title			Crosshair Changer
Author			MeusH (Amadeus Wieczorek)
E-Mail			amadeuszw@wp.pl  jedi@delart.pl
Website			jedi.delart.pl

File Name		crosshairs.pk3
File Size		7,31 KB
Date Released		27th january 2004

*************************
Description:
		
		It is a client-side MP mod that allows you select crosshair in "profile"
		menu.
		
		Run JA MP. Click on "profile". Select player, select saber and then
		new menu will open. It is a "crosshair selection" menu.
		You can select from 9 crosshairs or disable crosshair

		This mod doesn't work when you are using "The last hope" mod

		When I was making this mod, I've found one bug in saber creation menu:
		You couldn't go to Setup. Now it's fixed.


*************************
                                                 
Install 		: Unzip crosshairs.pk3 into your GAMEDATA\BASE folder
Uninstall               : Don't bother yourself uninstalling :)

How to use?		  Read "description"

*************************

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

