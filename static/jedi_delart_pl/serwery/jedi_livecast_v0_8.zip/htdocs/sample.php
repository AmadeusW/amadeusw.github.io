<?
include('server_query.php');
query_server('195.149.21.44','28071');
?>