DESANN'S RED SABER
============================================================================================
Author Information
============================================================================================
Author: MeusH
E-mail Address:	amadeuszw@wp.pl  jedi@delart.pl
Webpage:	www.jedi.delart.pl/projects.htm

============================================================================================
File Information
============================================================================================
Title: DESANN'S RED SABER
File Name: redsaber.pk3

It is a Jedi Knight II: Jedi Outcast mod

Date Of Release: 25th March 2004

Description: This mod replaces your saber with Desann's saber.
CFG file is also included. This scripth changes your sabercolor to red.

New models:	No
New HUD:	Yes
New sounds:	No
New saber:	Yes

============================================================================================
Installation Information
============================================================================================
Simply put the DesannSaber.pk3 in your jedioutcast/gamedata/base directory.
Run a game.
New hilt will appear, but to make red color, type to console this:
exec redsaber

============================================================================================
Known bugs
============================================================================================
Gameplay bugs: 0
Minor bugs: 1 (fixable)

When starting a game, saberblade doesn't come from hilt, but from air.
To fix that, just turn your saber on, off, on, off

============================================================================================
Construction Information
============================================================================================

Build Time: Two hours

Hope you enjoy it and thanks for playing.
       

============================================================================================
Permissions
============================================================================================
THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.
