*************************
JEDI ACADEMY MODIFICATION
*************************

Title			: Hidden Sabers
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: amadeuszw@wp.pl  jedi@delart.pl
Website			: jedi.delart.pl

File Name		: hiddensabers.pk3
File Size		: 604 bytes
Date Released		: 14th january 2004

*************************

Description		: This mod lets you play with new saber hilts:
				Luke Skywalker's 	(in game Skywalker)
				Desann's 		(in game Retribution)
				Reborns'		(in game Stinger)

*************************
                          
Comments		: I wanted to play with Desann's saber since I played JO.
			  So I've made possible playing with some hidden hilts!
                          Enjoy!

Build time              : 10 min :D            
                          
Install 		: Unzip the hiddenhilts.pk3 file into your BASE folder
Uninstall               : Delete hiddenhilts.pk3 from the BASE folder


*************************

THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

