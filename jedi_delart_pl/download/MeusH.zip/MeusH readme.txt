
JEDI ACADEMY MODIFICATION


Title			: MeusH
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: Amadeuszw@wp.pl , jedi@delart.pl
Website			: www.jedi.delart.pl

File Name		: MeusH.pk3
File Size		: 882 kb
Date Released		: 5th December 2003



This is a reskin of Rosh Penin:
	More hair over ears
	Brown hair
	Normal eyebrows
	Blue eyes
	Wider mouth
	Green (Blue or Red) shirt
	Jeans
	Light brown Boots


-New Sounds: YES 		(mixes Rosh's cinematics sounds and new)
-Team colors: YES
-Bot support: YES



How to install

Place the MeusH.pk3 in GameData\base in your game directory.




**                **

Copyright / Permissions
THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
ACTIVISION, RAVEN, OR LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

