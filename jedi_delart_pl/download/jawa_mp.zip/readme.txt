13th October 2003
================================================================
Model Name              : jk3 jawa_mp

Author                  : Dr.X (drx on jk2files)

Email Address           : agent_jam@msn.com

Model description       : all this is is the nessecary files to use the jawa's in mp (with red and blue team colours!). very simple, very fun.

Other Info		: there are also 2 secret jawa skins.

Additional Credits to   : Ravensoft and lucasarts of corse!

Thanks to               : the whole stinkin' world!
================================================================
to install stick in base folder

* Copyright / Permissions *

THIS MODEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY LLC.
ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

GO AHEAD TO WORK OFF THIS SKIN AS LONG AS I RECEIVE CREDIT.