*************************
JEDI ACADEMY MODIFICATION
*************************

Title			: Iktulam, the Jawa Warrior
Author			: MeusH (Amadeus Wieczorek)
E-Mail			: amadeuszw@wp.pl  jedi@delart.pl
Websites:
Poland only, about JA			jedi.delart.pl
For everybody, abiut my mods		jedi.delart.pl/projects.htm
Iktulam's website is in my mods site.
Welcome 

File Name		: jawawarrior.pk3
File Size		: 1,82 MB
Date Released		: 12 march 2004

*************************
Description:


New textures: Yes
Bot support: Yes
Team support: Yes
NPC: Yes
New sounds: Yes (made by Raven)

********************
******  ABOUT ******
********************

This is a nice cloaking skin of Jawa with glowing effect.

********************

Dark side bot is included.
Uses dual sabers.
Fast and deadly.

********************

Team versions are included + one "ghost" version!
If you want to play this hidden "ghost" version, type to console:
model jawawarrior/ghost

I heard that this ghost version is the best!

********************

Icons are glowing, too (to show how Jawa Warrior behaves in-game)

********************

There are also three npcs!

Iktulam
 default skin, medium opponent

  npc spawn iktulam



Iktulam's ghost
 ghost skin, hard opponent

  npc spawn iktulamghost



Iktulam helper
 blue skin, very good ally
 
 npc spawn ineedhelp



********************

Custom sounds are included. There are very fun!

********************

This mod was requested by TIE
 
********************
****** HOW TO ******
********************
                                                 
Install? 	 Unzip JawaWarrior.pk3 and into GAMEDATA\BASE folder

Use?		 Read "JawaWarriorReadme.txt"


********************
SOME NESSESARY LINES
********************
THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR 
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

